# SpeedLoc Pessoal

Projeto Android pessoal: câmera lê um localizador iFood de 8 dígitos e abre a página oficial de confirmação de entrega.

Build recomendado:
- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.5.2
- Kotlin 1.9.24
- task: :app:assembleDebug

O projeto não usa Autofill nesta versão.

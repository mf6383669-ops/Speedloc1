package com.matheus.speedlocpessoal

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Size
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var codeText: TextView
    private lateinit var openButton: Button
    private lateinit var rescanButton: Button

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val locked = AtomicBoolean(false)
    private var currentCode: String? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else statusText.text = "Permissão da câmera é necessária para escanear."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        codeText = findViewById(R.id.codeText)
        openButton = findViewById(R.id.openButton)
        rescanButton = findViewById(R.id.rescanButton)

        openButton.setOnClickListener {
            currentCode?.let { code -> openIfoodFlow(code) }
        }

        rescanButton.setOnClickListener {
            locked.set(false)
            currentCode = null
            codeText.text = ""
            openButton.isEnabled = false
            statusText.text = "Aponte a câmera para o localizador de 8 números"
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                if (locked.get()) {
                    imageProxy.close()
                    return@setAnalyzer
                }

                val mediaImage = imageProxy.image
                if (mediaImage == null) {
                    imageProxy.close()
                    return@setAnalyzer
                }

                val image = InputImage.fromMediaImage(
                    mediaImage,
                    imageProxy.imageInfo.rotationDegrees
                )

                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        val code = findEightDigitCode(result.text)
                        if (code != null && locked.compareAndSet(false, true)) {
                            runOnUiThread { showCode(code) }
                        }
                    }
                    .addOnCompleteListener {
                        imageProxy.close()
                    }
            }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun findEightDigitCode(text: String): String? {
        // Aceita somente uma sequência isolada de exatamente 8 dígitos.
        return Regex("""(?<!\d)\d{8}(?!\d)""")
            .find(text.replace(" ", ""))
            ?.value
    }

    private fun showCode(code: String) {
        currentCode = code
        getSharedPreferences("speedloc", MODE_PRIVATE)
            .edit()
            .putString("locator", code)
            .apply()
        codeText.text = code
        statusText.text = "Localizador identificado"
        openButton.isEnabled = true
    }

    private fun openIfoodFlow(locator: String) {
        // O iFood publica este endereço como a página padrão de confirmação
        // para entregas próprias. Antes de abrir, copiamos o localizador para
        // a área de transferência para que ele já esteja pronto para colar.
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(
            ClipData.newPlainText("Localizador iFood", locator)
        )

        val uri = Uri.parse("https://confirmacao-entrega-propria.ifood.com.br/")
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer.close()
        cameraExecutor.shutdown()
    }
}
